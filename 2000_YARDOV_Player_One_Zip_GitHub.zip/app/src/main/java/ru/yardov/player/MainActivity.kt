package ru.yardov.player

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

data class Track(val uri: String, val title: String, val artist: String, val album: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val player = ExoPlayer.Builder(this).build()
        setContent { YardovApp(this, player) }
    }
    override fun onDestroy() { super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YardovApp(context: Context, player: ExoPlayer) {
    val prefs = remember { context.getSharedPreferences("library", Context.MODE_PRIVATE) }
    fun loadTracks(): List<Track> {
        val arr = try { JSONArray(prefs.getString("tracks", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            Track(o.optString("uri"), o.optString("title", "Без названия"), o.optString("artist", "Неизвестный исполнитель"), o.optString("album", "Без альбома"))
        }
    }
    var tracks by remember { mutableStateOf(loadTracks()) }
    var tab by remember { mutableStateOf("Треки") }
    var selectedAlbum by remember { mutableStateOf<String?>(null) }
    var current by remember { mutableIntStateOf(-1) }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(1L) }
    var query by remember { mutableStateOf("") }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableStateOf(false) }
    val albums = tracks.map { it.album }.distinct().sorted()
    val artists = tracks.map { it.artist }.distinct().sorted()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val added = uris.mapNotNull { uri ->
                try {
                    context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {}
                val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "Аудиофайл"
                Track(uri.toString(), name.substringBeforeLast('.'), "Неизвестный исполнитель", "Без альбома")
            }
            val merged = (tracks + added).distinctBy { it.uri }
            tracks = merged
            val arr = JSONArray()
            merged.forEach { t -> arr.put(JSONObject().put("uri",t.uri).put("title",t.title).put("artist",t.artist).put("album",t.album)) }
            prefs.edit().putString("tracks", arr.toString()).apply()
        }
    }
    fun play(index: Int) {
        if (index !in tracks.indices) return
        current = index
        player.setMediaItem(MediaItem.fromUri(Uri.parse(tracks[index].uri)))
        player.prepare()
        player.play()
        playing = true
    }
    fun next() {
        if (tracks.isEmpty()) return
        val n = if (shuffle) tracks.indices.random() else (if (current < 0) 0 else (current + 1) % tracks.size)
        play(n)
    }
    LaunchedEffect(player) {
        while (true) {
            position = player.currentPosition.coerceAtLeast(0)
            duration = player.duration.takeIf { it > 0 } ?: 1L
            playing = player.isPlaying
            delay(500)
        }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    BackHandler(selectedAlbum != null) { selectedAlbum = null }
    val visibleTracks = tracks.filter { t ->
        (selectedAlbum == null || t.album == selectedAlbum) &&
        (query.isBlank() || "${t.title} ${t.artist} ${t.album}".contains(query, true))
    }
    val bg = Color(0xFF101010); val panel = Color(0xFF1D1D1D); val gold = Color(0xFFD6A64F)
    MaterialTheme(colorScheme = darkColorScheme(primary = gold, background = bg, surface = panel)) {
        Scaffold(containerColor = bg, topBar = {
            TopAppBar(
                title = { Column { Text("2000 ЯРДОВ", fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text(if (selectedAlbum != null) selectedAlbum!! else "МУЗЫКАЛЬНАЯ БИБЛИОТЕКА", fontSize = 10.sp, color = gold) } },
                navigationIcon = { if (selectedAlbum != null) IconButton(onClick={selectedAlbum=null}) { Icon(Icons.Default.ArrowBack, "Назад") } },
                actions = { IconButton(onClick={picker.launch(arrayOf("audio/*"))}) { Icon(Icons.Default.Add, "Добавить музыку") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = bg, titleContentColor = Color.White)
            )
        }, bottomBar = {
            Column(Modifier.background(panel).padding(horizontal=14.dp, vertical=8.dp)) {
                if (current >= 0 && current < tracks.size) {
                    Text(tracks[current].title, color=Color.White, fontWeight=FontWeight.Bold, maxLines=1)
                    Text(tracks[current].artist, color=Color.LightGray, fontSize=12.sp, maxLines=1)
                    Slider(value=position.toFloat().coerceIn(0f,duration.toFloat()), onValueChange={ position=it.toLong() }, onValueChangeFinished={ player.seekTo(position) }, valueRange=0f..duration.toFloat(), modifier=Modifier.height(28.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly, verticalAlignment=Alignment.CenterVertically) {
                        IconButton(onClick={shuffle=!shuffle}) { Icon(Icons.Default.Shuffle, "Случайно", tint=if(shuffle) gold else Color.Gray) }
                        IconButton(onClick={ if(current>0) play(current-1) else if(tracks.isNotEmpty()) play(tracks.lastIndex) }) { Icon(Icons.Default.SkipPrevious, "Предыдущий", tint=Color.White) }
                        IconButton(onClick={ if(player.isPlaying) { player.pause(); playing=false } else { if(current<0) next() else player.play(); playing=true } }) { Icon(if(playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Воспроизвести", tint=gold, modifier=Modifier.size(38.dp)) }
                        IconButton(onClick={next}) { Icon(Icons.Default.SkipNext, "Следующий", tint=Color.White) }
                        IconButton(onClick={repeat=!repeat; player.repeatMode=if(repeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF}) { Icon(Icons.Default.Repeat, "Повтор", tint=if(repeat) gold else Color.Gray) }
                    }
                } else {
                    Text("Добавь музыку, чтобы начать", color=Color.LightGray, modifier=Modifier.padding(8.dp))
                }
            }
        }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                OutlinedTextField(value=query, onValueChange={query=it}, placeholder={Text("Поиск по трекам, альбомам и исполнителям")}, leadingIcon={Icon(Icons.Default.Search,null)}, singleLine=true, modifier=Modifier.fillMaxWidth().padding(horizontal=12.dp, vertical=8.dp))
                if (selectedAlbum == null) {
                    ScrollableTabRow(selectedTabIndex=listOf("Треки","Альбомы","Исполнители").indexOf(tab), containerColor=bg, contentColor=gold) {
                        listOf("Треки","Альбомы","Исполнители").forEach { label -> Tab(selected=tab==label, onClick={tab=label}, text={Text(label)}) }
                    }
                }
                when {
                    selectedAlbum != null || tab=="Треки" -> {
                        if (visibleTracks.isEmpty()) EmptyState("Пока нет музыки", "Нажми + и выбери аудиофайлы")
                        else LazyColumn { items(visibleTracks) { t ->
                            val idx = tracks.indexOf(t)
                            Row(Modifier.fillMaxWidth().clickable { play(idx) }.padding(horizontal=16.dp, vertical=12.dp), verticalAlignment=Alignment.CenterVertically) {
                                Box(Modifier.size(48.dp).background(Color(0xFF303030), RoundedCornerShape(8.dp)), contentAlignment=Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint=gold) }
                                Column(Modifier.weight(1f).padding(start=12.dp)) { Text(t.title, color=Color.White, fontWeight=FontWeight.Medium, maxLines=1); Text("${t.artist} • ${t.album}", color=Color.Gray, fontSize=12.sp, maxLines=1) }
                                if(idx==current) Icon(Icons.Default.Equalizer, null, tint=gold)
                                IconButton(onClick={
                                    tracks=tracks.filterNot { it.uri==t.uri }
                                    val a=JSONArray(); tracks.forEach { x -> a.put(JSONObject().put("uri",x.uri).put("title",x.title).put("artist",x.artist).put("album",x.album)) }; prefs.edit().putString("tracks",a.toString()).apply()
                                    if(idx==current) { player.stop(); current=-1 }
                                }) { Icon(Icons.Default.DeleteOutline, "Удалить", tint=Color.Gray) }
                            }
                            Divider(color=Color(0xFF292929))
                        } }
                    }
                    tab=="Альбомы" -> {
                        val filtered=albums.filter { it.contains(query,true) }
                        if(filtered.isEmpty()) EmptyState("Альбомов пока нет", "Импортируй аудиофайлы")
                        else LazyColumn { items(filtered) { album ->
                            Row(Modifier.fillMaxWidth().clickable { selectedAlbum=album }.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                                Box(Modifier.size(58.dp).background(Color(0xFF303030),RoundedCornerShape(8.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.Album,null,tint=gold,modifier=Modifier.size(30.dp))}
                                Column(Modifier.padding(start=14.dp)) { Text(album,color=Color.White,fontWeight=FontWeight.Bold); Text("${tracks.count{it.album==album}} трек(ов)",color=Color.Gray,fontSize=12.sp) }
                            }
                        } }
                    }
                    else -> {
                        val filtered=artists.filter { it.contains(query,true) }
                        if(filtered.isEmpty()) EmptyState("Исполнителей пока нет", "Импортируй аудиофайлы")
                        else LazyColumn { items(filtered) { artist ->
                            Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Person,color=gold,contentDescription=null,modifier=Modifier.size(36.dp)); Column(Modifier.padding(start=14.dp)) { Text(artist,color=Color.White,fontWeight=FontWeight.Bold); Text("${tracks.count{it.artist==artist}} трек(ов)",color=Color.Gray,fontSize=12.sp) } }
                        } }
                    }
                }
            }
        }
    }
}
@Composable
fun EmptyState(title:String, subtitle:String) {
    Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Icon(Icons.Default.LibraryMusic, null, tint=Color(0xFFD6A64F), modifier=Modifier.size(56.dp))
        Spacer(Modifier.height(12.dp)); Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=18.sp)
        Text(subtitle,color=Color.Gray,fontSize=13.sp)
    }
}
